import React from 'react';

const CheckoutPage = () => {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Checkout</h2>

      {/* Order Summary */}
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">Order Summary</h5>
          <ul className="list-group">
            <li className="list-group-item d-flex justify-content-between">
              <span>Item 1</span>
              <span>₹100</span>
            </li>
            <li className="list-group-item d-flex justify-content-between">
              <span>Item 2</span>
              <span>₹150</span>
            </li>
            <li className="list-group-item d-flex justify-content-between font-weight-bold">
              <strong>Total</strong>
              <strong>₹250</strong>
            </li>
          </ul>
        </div>
      </div>

      {/* Payment Information */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Payment Information</h5>
          <form>
            <div className="mb-3">
              <label htmlFor="cardName" className="form-label">Cardholder Name</label>
              <input type="text" className="form-control" id="cardName" />
            </div>
            <div className="mb-3">
              <label htmlFor="cardNumber" className="form-label">Card Number</label>
              <input type="text" className="form-control" id="cardNumber" />
            </div>
            <div className="row">
              <div className="col-md-6 mb-3">
                <label htmlFor="expiryDate" className="form-label">Expiry Date</label>
                <input type="text" className="form-control" id="expiryDate" placeholder="MM/YY" />
              </div>
              <div className="col-md-6 mb-3">
                <label htmlFor="cvv" className="form-label">CVV</label>
                <input type="text" className="form-control" id="cvv" />
              </div>
            </div>
            <button type="submit" className="btn btn-success w-100">Place Order</button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
